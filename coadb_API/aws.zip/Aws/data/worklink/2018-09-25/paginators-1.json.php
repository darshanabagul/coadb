<?php
// This file was auto-generated from sdk-root/src/data/worklink/2018-09-25/paginators-1.json
return [ 'pagination' => [ 'ListDevices' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], 'ListFleets' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], 'ListWebsiteCertificateAuthorities' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], ],];
