<?php
// This file was auto-generated from sdk-root/src/data/metering.marketplace/2016-01-14/paginators-1.json
return [ 'pagination' => [],];
