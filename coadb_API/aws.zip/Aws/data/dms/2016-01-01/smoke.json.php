<?php
// This file was auto-generated from sdk-root/src/data/dms/2016-01-01/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'DescribeEndpoints', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'DescribeTableStatistics', 'input' => [ 'ReplicationTaskArn' => 'arn:aws:acm:region:123456789012', ], 'errorExpectedFromService' => true, ], ],];
