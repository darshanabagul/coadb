<?php
// This file was auto-generated from sdk-root/src/data/xray/2016-04-12/paginators-1.json
return [ 'pagination' => [ 'BatchGetTraces' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'result_key' => 'Traces', ], 'GetServiceGraph' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'result_key' => 'Services', ], 'GetTraceGraph' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'result_key' => 'Services', ], 'GetTraceSummaries' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'result_key' => 'TraceSummaries', ], ],];
