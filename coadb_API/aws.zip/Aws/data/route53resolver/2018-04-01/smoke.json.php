<?php
// This file was auto-generated from sdk-root/src/data/route53resolver/2018-04-01/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListResolverEndpoints', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'GetResolverRule', 'input' => [ 'ResolverRuleId' => 'fake-id', ], 'errorExpectedFromService' => true, ], ],];
